const Post = require('../models/Post');
const fs = require('fs');
const path = require('path');

// Create a new blog post
const createPost = async (req, res) => {
  try {
    const { title, content } = req.body;
    const image = req.file ? req.file.filename : null;

    const newPost = new Post({
      title,
      content,
      image,
      author: req.userId // comes from authMiddleware
    });

    await newPost.save();
    res.status(201).json({ message: 'Post created successfully', post: newPost });
  } catch (error) {
    console.error('Create post error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get all posts
const getAllPosts = async (req, res) => {
  try {
    const posts = await Post.find().populate('author', 'username email').sort({ createdAt: -1 });
    res.json(posts);
  } catch (error) {
    console.error('Get all posts error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get a single post by ID
const getPostById = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id).populate('author', 'username email');
    if (!post) return res.status(404).json({ message: 'Post not found' });
    res.json(post);
  } catch (error) {
    console.error('Get post by ID error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = { createPost, getAllPosts, getPostById };