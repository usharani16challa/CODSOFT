const Comment = require('../models/Comment');

const createComment = async (req, res) => {
  try {
    const { postId, username, text } = req.body;

    const newComment = new Comment({
      postId,
      username,
      text,
    });

    const savedComment = await newComment.save();
    res.status(201).json(savedComment);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const getCommentsByPost = async (req, res) => {
  try {
    const comments = await Comment.find({ postId: req.params.postId }).sort({ createdAt: -1 });
    res.status(200).json(comments);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = {
  createComment,
  getCommentsByPost,
};