const express = require('express');
const mongoose=require('mongoose');
const router = express.Router();
const { createPost, getAllPosts, getPostById } = require('../controllers/postController');
const authMiddleware = require('../middleware/authMiddleware');
const multer = require('multer');
const path = require('path');
const Post=require('../models/Post');

// Multer setup for image upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // folder must exist
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});
const upload = multer({ storage });

// POST /api/posts - Create post (with image)
router.post('/', authMiddleware, upload.single('image'), createPost);

// GET /api/posts - Get all posts
router.get('/', getAllPosts);

// GET /api/posts/:id - Get single post
router.get('/:id', getPostById);

module.exports = router;