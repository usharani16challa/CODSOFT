const express = require('express');
const router = express.Router();
const Comment = require('../models/Comment');

// Create comment
router.post('/', async (req, res) => {
  const { postId, text } = req.body;
  try {
    const comment = new Comment({ postId, text });
    await comment.save();
    res.json(comment);
  } catch (err) {
    res.status(500).json({ error: 'Failed to save comment' });
  }
});

// Get comments for a post
router.get('/:postId', async (req, res) => {
  try {
    const comments = await Comment.find({ postId: req.params.postId });
    res.json(comments);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch comments' });
  }
});

module.exports = router;