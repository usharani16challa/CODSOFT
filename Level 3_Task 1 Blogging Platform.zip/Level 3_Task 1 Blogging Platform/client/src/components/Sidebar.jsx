import React from 'react';
import { Link } from 'react-router-dom';

const Sidebar = () => (
  <div className="bg-gray-100 p-4 w-full sm:w-1/4">
    <h2 className="text-2xl font-bold mb-4 text-indigo-600">Usharani Blog</h2>
    <ul className="space-y-2">
      <li><Link to="/" className="text-blue-600 hover:underline">Home</Link></li>
      <li><Link to="/create" className="text-blue-600 hover:underline">Create</Link></li>
      <li><Link to="/login" className="text-blue-600 hover:underline">Login</Link></li>
      <li><Link to="/register" className="text-blue-600 hover:underline">Register</Link></li>
    </ul>
  </div>
);

export default Sidebar;