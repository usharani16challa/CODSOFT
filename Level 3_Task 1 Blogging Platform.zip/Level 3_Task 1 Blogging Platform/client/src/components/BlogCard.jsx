import React from 'react';
import { Link } from 'react-router-dom';

const BlogCard = ({ post }) => (
  <div className="bg-white rounded-lg shadow-md overflow-hidden">
    {post.image && (
      <img
        src={`http://localhost:5000/uploads/${post.image}`}
        alt={post.title}
        className="w-full h-48 object-cover"
      />
    )}
    <div className="p-4">
      <h2 className="text-xl font-semibold text-gray-800">{post.title}</h2>
      <p className="text-gray-600 mt-2">{post.content.slice(0, 100)}...</p>
      <Link to={`/post/${post._id}`} className="inline-block mt-3 text-blue-600 hover:underline">
        Read more
      </Link>
    </div>
  </div>
);

export default BlogCard;