import React, { useState } from 'react';

function CommentSection({ postId }) {
  const [comment, setComment] = useState('');
  const [comments, setComments] = useState([]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!comment.trim()) return;

    const response = await fetch(`http://localhost:5000/api/comments/${postId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ text: comment })
    });

    const data = await response.json();
    if (response.ok) {
      setComments([...comments, data.text]); // assuming data.text is returned
      setComment('');
    }
  };

  return (
    <div className="mt-4">
      <h3 className="font-bold text-purple-700 mb-2">Comments</h3>
      <form onSubmit={handleSubmit} className="flex flex-col space-y-2">
        <textarea
          className="border p-2 rounded"
          placeholder="Write a comment..."
          value={comment}
          onChange={(e) => setComment(e.target.value)}
        ></textarea>
        <button
          type="submit"
          className="bg-purple-600 text-white py-1 px-4 rounded hover:bg-purple-700"
        >
          Submit
        </button>
      </form>
      <div className="mt-3">
        {comments.map((c, i) => (
          <div key={i} className="bg-gray-100 p-2 my-1 rounded">{c}</div>
        ))}
      </div>
    </div>
  );
}

export default CommentSection;