import axios from 'axios';

const API = axios.create({
  baseURL: 'http://localhost:5000/api', // adjust this if backend is hosted
  withCredentials: true, // needed for sending cookies/token if any
  headers: {
    'Content-Type': 'application/json'
  }
});

export default API;