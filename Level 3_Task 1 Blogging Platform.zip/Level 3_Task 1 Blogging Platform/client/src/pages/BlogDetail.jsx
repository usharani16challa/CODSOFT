import React, { useState, useEffect } from 'react';
import axios from 'axios';

function BlogDetail({ postId }) {
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');

  useEffect(() => {
    axios.get(`/api/comments/${postId}`).then(res => {
      setComments(res.data);
    });
  }, [postId]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post(`/api/comments/${postId}`, {
      username: 'Guest',
      content: newComment
    });
    setNewComment('');
    const res = await axios.get(`/api/comments/${postId}`);
    setComments(res.data);
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold">Comments</h2>
      {comments.map((c, i) => (
        <div key={i} className="p-2 border-b">
          <p className="font-semibold">{c.username}</p>
          <p>{c.content}</p>
        </div>
      ))}

      <form onSubmit={handleSubmit} className="mt-4">
        <textarea
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          placeholder="Add your comment..."
          className="w-full p-2 border rounded"
        />
        <button type="submit" className="mt-2 bg-purple-600 text-white px-4 py-1 rounded">
          Post Comment
        </button>
      </form>
    </div>
  );
}

export default BlogDetail;