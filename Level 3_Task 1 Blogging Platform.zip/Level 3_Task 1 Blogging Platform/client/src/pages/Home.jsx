import React, { useState } from 'react';
import {Link} from 'react-router-dom';

const blogPosts = [
  {
    title: "Exploring the Beaches of Goa",
    image: "/images/post1.jpg",
    summary: "A perfect getaway with sun, sand, and waves.",
  },
  {
    title: "Trekking the Himalayas",
    image: "/images/post2.jpg",
    summary: "An unforgettable adventure to the roof of the world.",
  },
  {
    title: "Delicious Street Food in Hyderabad",
    image: "/images/post3.jpg",
    summary: "From biryani to kebabs, experience it all.",
  },
  {
    title: "Backwaters of Kerala",
    image: "/images/post4.jpg",
    summary: "A calm and serene boat ride through nature.",
  },
  {
    title: "Desert Safari in Rajasthan",
    image: "/images/post5.jpg",
    summary: "Camels, dunes, and cultural magic.",
  },
  {
    title: "Modern Life in Bangalore",
    image: "/images/post6.jpg",
    summary: "Explore the IT capital's food and cafes.",
  },
];

function Home() {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredPosts = blogPosts.filter((post) =>
    post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.summary.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      {/* Top Nav / Title */}
      <header className="bg-purple-700 text-white p-4 text-center text-2xl font-bold shadow">
        Usharani Blogging Platform
      </header>

      <div className="flex flex-1">
        {/* Left Sidebar */}
        <aside className="w-1/4 bg-white p-6 shadow-md">
          <nav className="space-y-4 text-purple-700 font-semibold">
            <p className="text-lg font-bold mb-4">Menu</p>
            <a href="#" className="block hover:text-purple-500">Home</a>
            <a href="#" className="block hover:text-purple-500">Create</a>
            <a href="#" className="block hover:text-purple-500">Login</a>
            <a href="#" className="block hover:text-purple-500">Register</a>
            <p className="mt-6 text-sm text-gray-500">Usharani Blog © 2025</p>
          </nav>
        </aside>

        {/* Right Blog Posts */}
        <main className="w-3/4 p-6">
          {/* 🔍 Search Bar */}
          <div className="mb-6">
            <input
              type="text"
              placeholder="Search blog posts..."
              className="w-full p-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          {/* 📄 Blog Posts */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPosts.map((post, index) => (
              <Link to={`/post/${index}`} key={index}>
              <div key={index} className="bg-white rounded-xl shadow hover:shadow-lg transition p-4">
                <img src={post.image} alt={post.title} className="w-full h-40 object-cover rounded" />
                <h2 className="text-xl font-semibold mt-3">{post.title}</h2>
                <p className="text-gray-600 text-sm mt-1">{post.summary}</p>
              </div>
              </Link>
            ))}
          </div>
        </main>
      </div>

      {/* Footer */}
      <footer className="bg-purple-700 text-white text-center p-4">
        © 2025 Usharani Blog. All rights reserved.
      </footer>
    </div>
  );
}

export default Home;