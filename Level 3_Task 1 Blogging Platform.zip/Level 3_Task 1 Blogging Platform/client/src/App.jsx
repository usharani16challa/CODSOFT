import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import CreatePost from './pages/CreatePost';
import BlogDetail from './pages/BlogDetail';

function App() {
  return (
    <Router>
      <div className="bg-blue-100 min-h-screen flex items-center justify-center">
        <div className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/create" element={<CreatePost />} />
            <Route path="/post/:id" element={<BlogDetail />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;