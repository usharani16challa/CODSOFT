import React, { useState } from 'react';
import axios from 'axios';

const TaskForm = ({ projectId }) => {
  const [title, setTitle] = useState('');
  const [deadline, setDeadline] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post('http://localhost:5000/api/tasks', {
      projectId,
      title,
      deadline,
    });
    setTitle('');
    setDeadline('');
  };

  return (
    <form onSubmit={handleSubmit} className="mb-6 bg-white p-4 rounded shadow">
      <h2 className="text-xl font-bold mb-2">Add Task</h2>
      <input
        type="text"
        placeholder="Task Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        className="w-full border p-2 mb-2 rounded"
      />
      <input
        type="date"
        value={deadline}
        onChange={(e) => setDeadline(e.target.value)}
        className="w-full border p-2 mb-2 rounded"
      />
      <button className="bg-green-600 text-white px-4 py-2 rounded">Add Task</button>
    </form>
  );
};

export default TaskForm;