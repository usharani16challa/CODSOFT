import React, { useEffect, useState } from 'react';
import axios from 'axios';

const TaskList = ({ projectId }) => {
  const [tasks, setTasks] = useState([]);

  const fetchTasks = async () => {
    const res = await axios.get(`http://localhost:5000/api/tasks/${projectId}`);
    setTasks(res.data);
  };

  const updateStatus = async (id, status) => {
    await axios.put(`http://localhost:5000/api/tasks/${id}/status`, { status });
    fetchTasks();
  };

  useEffect(() => {
    fetchTasks();
  }, [projectId]);

  return (
    <div className="bg-white p-4 rounded shadow">
      <h2 className="text-xl font-bold mb-2">Task List</h2>
      {tasks.map((task) => (
        <div key={task._id} className="border p-3 rounded mb-2">
          <h3 className="font-semibold">{task.title}</h3>
          <p className="text-sm text-gray-500">Deadline: {task.deadline?.split("T")[0]}</p>
          <select
            value={task.status}
            onChange={(e) => updateStatus(task._id, e.target.value)}
            className="mt-2 border p-1 rounded"
          >
            <option>To Do</option>
            <option>In Progress</option>
            <option>Completed</option>
          </select>
        </div>
      ))}
    </div>
  );
};

export default TaskList;