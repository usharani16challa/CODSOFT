import React, { useState } from 'react';
import axios from 'axios';

const ProjectForm = ({ onCreated }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post('http://localhost:5000/api/projects', { name, description });
    setName('');
    setDescription('');
    onCreated();
  };

  return (
    <form onSubmit={handleSubmit} className="mb-6 bg-white p-4 rounded shadow">
      <h2 className="text-xl font-bold mb-2">Create Project</h2>
      <input
        type="text"
        placeholder="Project Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        className="w-full border p-2 mb-2 rounded"
      />
      <textarea
        placeholder="Description"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        className="w-full border p-2 mb-2 rounded"
      />
      <button className="bg-blue-600 text-white px-4 py-2 rounded">Create</button>
    </form>
  );
};

export default ProjectForm;