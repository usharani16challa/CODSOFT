module.exports = {
  plugins: {
    '@tailwindcss/postcss': {}, // Use @tailwindcss/postcss instead of tailwindcss
    autoprefixer: {},
  },
};