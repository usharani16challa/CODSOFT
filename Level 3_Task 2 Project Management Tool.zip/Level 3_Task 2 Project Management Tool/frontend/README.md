# Project Management Tool

A web-based project management tool built with React, Node.js, and MongoDB. Features include user authentication, project/task creation, deadlines, and progress tracking.

## Tech Stack
- *Frontend*: React, Tailwind CSS, React Router
- *Backend*: Node.js, Express, MongoDB
- *Authentication*: JWT
- *Hosting*: Netlify (Frontend), Render (Backend), MongoDB Atlas (Database)
- *Version Control*: GitLab

## Setup Instructions

### Backend
1. Navigate to backend:
   ```bash
   cd backend