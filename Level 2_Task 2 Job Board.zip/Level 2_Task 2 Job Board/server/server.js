const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');

const User = require('./models/User');
const Job = require('./models/Job');
const Application = require('./models/Application');

const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// MongoDB Connect
mongoose.connect('mongodb://127.0.0.1:27017/jobboard', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// JWT Auth Middleware
const auth = (req, res, next) => {
  const token = req.headers.authorization;
  if (!token) return res.status(401).json({ message: 'Unauthorized' });

  try {
    const decoded = jwt.verify(token, 'your_jwt_secret');
    req.userId = decoded.id;
    next();
  } catch (err) {
    res.status(401).json({ message: 'Invalid token' });
  }
};

// Multer Setup for Resume Upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  },
});
const upload = multer({ storage });

// ✅ Signup
app.post('/signup', async (req, res) => {
  const { name, email, password } = req.body;

  try {
    console.log("Signup request received:", req.body); // ✅ Debug log

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      console.log("User already exists");
      return res.status(400).json({ message: 'User already exists' });
    }

    const hashed = await bcrypt.hash(password, 10);
    const user = new User({ name, email, password: hashed });
    await user.save();

    const token = jwt.sign({ id: user._id }, 'your_jwt_secret');
    res.status(201).json({ user, token });
  } catch (err) {
    console.error("❌ Signup failed:", err);
    res.status(500).json({ message: 'Signup failed', error: err.message });
  }
});

// ✅ Login
app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ message: 'User not found' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ message: 'Invalid credentials' });

    const token = jwt.sign({ id: user._id }, 'your_jwt_secret');
    res.status(200).json({ user, token });
  } catch (err) {
    res.status(500).json({ message: 'Login failed' });
  }
});

// ✅ Post a Job (Employer Only)
app.post('/jobs', auth, async (req, res) => {
  const { title, description, company, location } = req.body;
  try {
    const job = new Job({ title, description, company, location, postedBy: req.userId });
    await job.save();
    res.status(201).json({ message: 'Job posted', job });
  } catch (err) {
    res.status(500).json({ message: 'Job post failed' });
  }
});

// ✅ Get All Jobs
app.get('/jobs', async (req, res) => {
  try {
    const jobs = await Job.find().sort({ createdAt: -1 });
    res.json(jobs);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch jobs' });
  }
});

// ✅ Apply to a Job (With Resume Upload)
app.post('/apply/:jobId', auth, upload.single('resume'), async (req, res) => {
  try {
    const application = new Application({
      jobId: req.params.jobId,
      candidateId: req.userId,
      resumePath: req.file.path,
    });
    await application.save();
    res.status(201).json({ message: 'Application submitted', application });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Application failed' });
  }
});

// ✅ Get Candidate Applications
app.get('/applications', auth, async (req, res) => {
  try {
    const applications = await Application.find({ candidateId: req.userId }).populate('jobId');
    res.json(applications);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch applications' });
  }
});

// ✅ Start Server
app.listen(5000, () => {
  console.log('🚀 Server running on http://localhost:5000');
});