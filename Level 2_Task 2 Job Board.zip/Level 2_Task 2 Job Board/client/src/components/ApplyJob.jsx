import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

function ApplyJob() {
  const { id } = useParams(); // job ID from URL
  const [name, setName] = useState('');
  const [resume, setResume] = useState(null);
  const [message, setMessage] = useState('');

  const handleApply = async (e) => {
    e.preventDefault();
    if (!name || !resume) return setMessage('Please enter your name and upload resume');

    const formData = new FormData();
    formData.append('name', name);
    formData.append('resume', resume);
    formData.append('jobId', id);

    try {
      const res = await axios.post('http://localhost:5000/apply', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      setMessage(res.data.message || 'Application submitted!');
    } catch (err) {
      console.error(err);
      setMessage('Application failed. Try again.');
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Apply for this Job</h2>
      <form onSubmit={handleApply}>
        <div>
          <label>Name: </label><br />
          <input
            type="text"
            value={name}
            onChange={e => setName(e.target.value)}
            required
            style={{ padding: '8px', width: '300px' }}
          />
        </div>
        <div style={{ marginTop: '10px' }}>
          <label>Upload Resume: </label><br />
          <input
            type="file"
            onChange={e => setResume(e.target.files[0])}
            required
          />
        </div>
        <button type="submit" style={{ marginTop: '15px', padding: '10px 20px' }}>
          Submit Application
        </button>
      </form>
      <p style={{ marginTop: '20px', color: 'green' }}>{message}</p>
    </div>
  );
}

export default ApplyJob;