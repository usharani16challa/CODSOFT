import React, { useEffect, useState } from 'react';

function CandidateDashboard() {
  const [applications, setApplications] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchApplications = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await fetch('http://localhost:5000/applications', {
          headers: {
            Authorization:`Bearer ${token}`
          }
        });

        if (!response.ok) {
          throw new Error('Failed to fetch applications');
        }

        const data = await response.json();
        setApplications(data);
      } catch (err) {
        console.error("Error:", err);
        setError('Something went wrong');
      }
    };

    fetchApplications();
  }, []);

  return (
    <div className="dashboard">
      <h2>Candidate Dashboard</h2>
      <p>Welcome! Here are your job applications:</p>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      {applications.length === 0 ? (
        <p>No applications yet.</p>
      ) : (
        <ul>
          {applications.map((app) => (
            <li key={app._id}>
              <strong>{app.jobId?.title}</strong> - Applied on {new Date(app.createdAt).toLocaleDateString()}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default CandidateDashboard;