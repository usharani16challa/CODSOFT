import React from 'react';
import { useNavigate } from 'react-router-dom';
import './HeroSection.css';

function HeroSection() {
  const navigate = useNavigate();

  const handleApplyClick = () => {
    navigate('/upload-resume');
  };

  return (
    <div className="hero-section">
      <div className="hero-text">
        <h1>4536+ Jobs Listed</h1>
        <p>Find your dream job. Apply now with a single click!</p>
        <button className="apply-button" onClick={handleApplyClick}>
          Upload Your Resume
        </button>
      </div>
      <div className="hero-image">
        <img src="/images/hero.jpg" alt="Hero" />
      </div>
    </div>
  );
}

export default HeroSection;