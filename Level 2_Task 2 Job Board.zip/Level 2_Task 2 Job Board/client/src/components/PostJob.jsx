import React, { useState } from 'react';

function PostJob() {
  const [jobData, setJobData] = useState({
    title: '',
    company: '',
    location: '',
    description: ''
  });

  const handleChange = (e) => {
    setJobData({ ...jobData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('token');

    if (!token) {
      alert('You must be logged in as an employer to post a job.');
      return;
    }

    try {
      const response = await fetch("http://localhost:5000/postjob", {
        method: 'POST',
        headers: {
          "Content-Type": "application/json",
          Authorization:`Bearer ${token}`,
        },
        body: JSON.stringify(jobData),
      });

      const data = await response.json();
      if (response.ok) {
        alert('Job posted successfully!');
        setJobData({ title: '', company: '', location: '', description: '' });
      } else {
        alert(data.message || 'Failed to post job.');
      }
    } catch (error) {
      console.error('Error posting job:', error);
      alert('An error occurred.');
    }
  };

  return (
    <div className="post-job-container">
      <h2>Post a Job</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="title"
          placeholder="Job Title"
          value={jobData.title}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="company"
          placeholder="Company"
          value={jobData.company}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="location"
          placeholder="Location"
          value={jobData.location}
          onChange={handleChange}
          required
        />
        <textarea
          name="description"
          placeholder="Job Description"
          value={jobData.description}
          onChange={handleChange}
          required
        ></textarea>
        <button type="submit">Post Job</button>
      </form>
    </div>
  );
}

export default PostJob;