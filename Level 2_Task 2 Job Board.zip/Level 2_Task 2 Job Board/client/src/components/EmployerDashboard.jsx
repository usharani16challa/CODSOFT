import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function EmployerDashboard() {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/jobs')
      .then(res => setJobs(res.data))
      .catch(err => console.error(err));
  }, []);

  const deleteJob = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/jobs/${id}`);
      setJobs(jobs.filter(job => job._id !== id));
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Employer Dashboard</h2>
      <p>Welcome! You can post and manage job listings here.</p>
      <Link to="/post-job">➕ Post New Job</Link>
      <ul>
        {jobs.map(job => (
          <li key={job._id} style={{ margin: '15px 0' }}>
            <strong>{job.title}</strong> – {job.company}
            <button onClick={() => deleteJob(job._id)} style={{ marginLeft: '10px' }}>🗑 Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default EmployerDashboard;