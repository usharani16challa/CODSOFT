import React from 'react';

function
SearchBar({searchTerm,setSearchTerm}){
    return(
        <div style={{textAlign:'center',marginBottom:'20px'}}>

            <input 
             type="text"
             placeholder="Search by job title or company"
             value={searchTerm}
             onChange={(e)=>setSearchTerm(e.target.value)}
             style={{
                width:'60%',
                padding:'10px',
                borderRadius:'5px',
                border:'1px solid #ccc'
             }}
            />
        </div>
    );
}

export default SearchBar;