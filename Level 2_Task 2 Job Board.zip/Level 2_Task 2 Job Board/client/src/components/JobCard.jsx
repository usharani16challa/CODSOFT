import React from 'react';

function JobCard({ job }) {
  const handleApply = async () => {
    const token = localStorage.getItem("token");
    if (!token) {
      alert("Please login first.");
      return;
    }

    try {
      const response = await fetch('http://localhost:5000/apply', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: Bearer ${token}
        },
        body: JSON.stringify({
          jobId: job._id,
          resume: "resume.pdf" // just a placeholder for now
        })
      });

      const data = await response.json();
      if (response.ok) {
        alert("Applied successfully!");
      } else {
        alert(data.message || "Application failed.");
      }
    } catch (err) {
      console.error("Error:", err);
      alert("Something went wrong.");
    }
  };

  return (
    <div className="job-card">
      <h3>{job.title}</h3>
      <p>{job.description}</p>
      <button onClick={handleApply}>Apply Now</button>
    </div>
  );
}

export default JobCard;