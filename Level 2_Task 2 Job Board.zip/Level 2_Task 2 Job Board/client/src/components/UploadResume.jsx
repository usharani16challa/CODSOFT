import React, { useState } from 'react';

function UploadResume() {
  const [resume, setResume] = useState(null);

  const handleFileChange = (e) => {
    setResume(e.target.files[0]);
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!resume) {
      alert('Please select a file');
      return;
    }

    const formData = new FormData();
    formData.append('resume', resume);

    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5000/upload', {
        method: 'POST',
        headers: {
          Authorization:`Bearer ${token}`
        },
        body: formData
      });

      const data = await response.json();
      if (response.ok) {
        alert('Resume uploaded successfully!');
      } else {
        alert(data.message || 'Upload failed');
      }
    } catch (error) {
      console.error("Upload error:",error);
      alert('Something went wrong while uploading');
    }
  };

  return (
    <div style={{ padding: '40px' }}>
      <h2>Upload Your Resume</h2>
      <form onSubmit={handleUpload}>
        <input type="file" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" onChange={handleFileChange} />
        <br /><br />
        <button type="submit">Upload</button>
      </form>
    </div>
  );
}

export default UploadResume;