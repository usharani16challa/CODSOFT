import React from 'react';
import { Link } from 'react-router-dom';

function Navbar() {
  return (
    <nav style={{
      background: '#333',
      color: '#fff',
      padding: '10px 20px',
      display: 'flex',
      justifyContent: 'space-between'
    }}>
      <div style={{ fontWeight: 'bold' }}>JobBoard</div>
      <div>
        <Link to="/" style={{ color: '#fff', marginRight: '15px' }}>Home</Link>
        <Link to="/jobs" style={{ color: '#fff', marginRight: '15px' }}>Jobs</Link>
        <Link to="/post-job" style={{ color: '#fff', marginRight: '15px' }}>Post Job</Link>
        <Link to="/login" style={{ color: '#fff', marginRight: '15px' }}>Login</Link>
        <Link to="/signup" style={{ color: '#fff', marginRight: '15px' }}>Signup</Link>
        <Link to="/employer-dashboard" style={{ color: '#fff', marginRight: '15px' }}>Employer</Link>
        <Link to="/candidate-dashboard" style={{ color: '#fff' }}>Candidate</Link>
      </div>
    </nav>
  );
}

export default Navbar;