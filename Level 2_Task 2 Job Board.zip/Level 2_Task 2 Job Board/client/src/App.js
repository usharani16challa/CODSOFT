import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';

import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import JobList from './components/JobList';
import PostJob from './components/PostJob';
import Register from './components/Register';
import Login from './components/Login';
import EmployerDashboard from './components/EmployerDashboard';
import CandidateDashboard from './components/CandidateDashboard';
import JobDetail from './components/JobDetail';
import ApplyJob from './components/ApplyJob';
import Signup from './components/Signup';
import UploadResume from './components/UploadResume';

function App() {
  const [role, setRole] = useState(localStorage.getItem('role'));

  const handleLogin = () => {
    setRole(localStorage.getItem('role'));
  };

  return (
    <>
      <Navbar/>
       <Routes>
         <Route path="/" element={<HeroSection />} />
         <Route path="/jobs" element={<JobList />} />
         <Route path="/post-job" element={<PostJob />} />
         <Route path="/register" element={<Register />} />
         <Route path="/login" element={<Login onLogin={handleLogin} />} />
         <Route path="/jobs/:id" element={<JobDetail/>}/>
         <Route path="/apply/:id" element={<ApplyJob/>}/>
         <Route path="/candidate-dashboard" element={<CandidateDashboard/>}/>
         <Route path="/employer-dashboard" element={<EmployerDashboard/>}/>
         <Route path="/signup" element={<Signup/>}/>
         <Route path="/upload-resume" element={<UploadResume/>}/>
       </Routes>
    </>  
  );
}

export default App;